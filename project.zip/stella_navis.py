import pygame
import os
import random
import sys

FPS = 60

enemies = ['enemy.png', 'enemy.png', 'enemy2.png', 'enemy2.png', 'enemy3.png']

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

start_button = (287, 125)

pygame.init()
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
pygame.display.set_caption("Stella navis")
clock = pygame.time.Clock()

HEIGHT = screen.get_height()

WIDTH = screen.get_width()

font_name = pygame.font.match_font('arial')


def snd_name(name):

    return os.path.join("game_data", name)


sound1 = pygame.mixer.Sound(snd_name('choose.wav'))
sound2 = pygame.mixer.Sound(snd_name('hurt.wav'))
sound3 = pygame.mixer.Sound(snd_name('game_over.wav'))
sound4 = pygame.mixer.Sound(snd_name('death.wav'))
sound5 = pygame.mixer.Sound(snd_name('shoot.wav'))


def load_image(name, colorkey=None):
    fullname = os.path.join('game_data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
    if colorkey == -1:
        colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def draw_text(surf, text, size, x, y):
    font = pygame.font.Font(font_name, size)
    text_surface = font.render(text, True, WHITE)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)


def draw_shield_bar(surf, x, y, pct):
    if pct < 0:
        pct = 0
    BAR_LENGTH = 100
    BAR_HEIGHT = 20
    fill = (pct / 100) * BAR_LENGTH
    outline_rect = pygame.Rect(x, y, BAR_LENGTH * 4, BAR_HEIGHT)
    fill_rect = pygame.Rect(x, y, fill, BAR_HEIGHT)
    pygame.draw.rect(surf, GREEN, fill_rect)
    pygame.draw.rect(surf, WHITE, outline_rect, 2)


class Player(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = load_image('plane.png', -1)
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH / 2
        self.rect.bottom = HEIGHT - 10
        self.speedx = 0
        self.shield = 400

    def update(self, x):
        self.rect.x = x

    def shoot(self):
        bullet1 = Bullet(self.rect.centerx - 20, self.rect.top + 20)
        bullet2 = Bullet(self.rect.centerx + 20, self.rect.top + 20)
        all_sprites.add(bullet1, bullet2)
        bullets.add(bullet1, bullet2)


class Mob(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.name = random.choice(enemies)
        self.image = load_image(self.name, -1)
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(200, WIDTH - 300)
        self.rect.y = random.randrange(-400, -200)
        self.speedy = random.randrange(10, 18)
        self.speedx = random.randrange(-3, 4)

    def update(self):
        self.name = random.choice(enemies)
        self.rect.x += self.speedx
        self.rect.y += self.speedy
        if self.rect.top > HEIGHT + 10 or self.rect.left < -25 or self.rect.right > WIDTH + 25:
            self.image = load_image(self.name, -1)
            self.rect.x = random.randrange(200, WIDTH - 300)
            self.rect.y = random.randrange(-400, -200)
            self.speedy = random.randrange(10, 18)
            self.speedx = random.randrange(-3, 4)


class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = load_image('bullet.png', -1)
        self.rect = self.image.get_rect()
        self.rect.bottom = y
        self.rect.centerx = x
        self.speedy = -20

    def update(self):
        self.rect.y += self.speedy
        if self.rect.bottom < 0:
            self.kill()


class Fon(pygame.sprite.Sprite):
    def __init__(self, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = load_image('space.png')
        self.rect = self.image.get_rect()
        self.rect.y = y

    def update(self):
        self.rect.top += 2
        if self.rect.top > HEIGHT:
            self.rect.top = -HEIGHT


def start_screen():

    global running

    fon = load_image('fon.png')
    screen.blit(fon, (0, 0))

    cursor = pygame.sprite.Group()

    sprite = pygame.sprite.Sprite()

    sprite.image = load_image('cursor.png', -1)

    sprite.rect = sprite.image.get_rect()

    cursor.add(sprite)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                sound1.play()
                if 295 < x < 574 and 379 < y < 491:
                    return
                if 298 < x < 515 and 630 < y < 712:
                    running = False
                if 287 < x < 753 and 519 < y < 611:
                    controls()
            elif event.type == pygame.MOUSEMOTION:
                if pygame.mouse.get_focused():
                    pygame.mouse.set_visible(False)
                    screen.fill((0, 0, 0))
                    sprite.rect.x = event.pos[0]

                    sprite.rect.y = event.pos[1]

        screen.blit(fon, (0, 0))
        cursor.draw(screen)
        pygame.display.flip()


def controls():
    controls = load_image('controls.png')
    screen.blit(controls, (0, 0))

    cursor = pygame.sprite.Group()

    sprite1 = pygame.sprite.Sprite()

    sprite1.image = load_image('cursor.png', -1)

    sprite1.rect = sprite1.image.get_rect()

    cursor.add(sprite1)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                sound1.play()
                x, y = pygame.mouse.get_pos()
                if 0 < x < 202 and 0 < y < 120:
                    return
            elif event.type == pygame.MOUSEMOTION:
                if pygame.mouse.get_focused():
                    pygame.mouse.set_visible(False)
                    screen.fill((0, 0, 0))
                    sprite1.rect.x = event.pos[0]

                    sprite1.rect.y = event.pos[1]

        screen.blit(controls, (0, 0))
        cursor.draw(screen)
        pygame.display.flip()


def game_over(score):
    over = load_image('game_over.png')
    screen.blit(over, (0, 0))

    cursor = pygame.sprite.Group()

    sprite1 = pygame.sprite.Sprite()

    sprite1.image = load_image('cursor.png', -1)

    sprite1.rect = sprite1.image.get_rect()

    cursor.add(sprite1)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                sound1.play()
                x, y = pygame.mouse.get_pos()
                if 602 < x < 844 and 604 < y < 698:
                    return
            elif event.type == pygame.MOUSEMOTION:
                if pygame.mouse.get_focused():
                    pygame.mouse.set_visible(False)
                    screen.fill((0, 0, 0))
                    sprite1.rect.x = event.pos[0]

                    sprite1.rect.y = event.pos[1]

        screen.blit(over, (0, 0))
        draw_text(screen, str(score), 50, 981, 461)
        cursor.draw(screen)
        pygame.display.flip()


running = True

start_screen()

all_sprites = pygame.sprite.Group()
mobs = pygame.sprite.Group()
bullets = pygame.sprite.Group()
fons = pygame.sprite.Group()
player = Player()

fon1 = Fon(0)
fon2 = Fon(-HEIGHT)

all_sprites.add(fon1)
all_sprites.add(fon2)

fons.add(fon1)
fons.add(fon2)

all_sprites.add(player)
for i in range(6):
    m = Mob()
    all_sprites.add(m)
    mobs.add(m)
score = 0

shoot_count = 0

shoot_speed = 10

while running:
    fons.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            sound5.play()
            player.shoot()

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                start_screen()

    if pygame.mouse.get_pressed()[0]:
        shoot_count += 1
        if shoot_count % shoot_speed == 0:
            player.shoot()
            sound5.play()
            shoot_count = 0

    player.update(pygame.mouse.get_pos()[0])
    mobs.update()
    bullets.update()

    hits = pygame.sprite.groupcollide(mobs, bullets, True, True)
    for hit in hits:
        sound4.play()
        score += 1

    hits = pygame.sprite.spritecollide(
        player, mobs, True, pygame.sprite.collide_circle)

    for hit in hits:
        sound2.play()
        player.shield -= 100
        if player.shield <= 0:
            sound3.play()
            game_over(score)
            running = False
    count = 0
    for i in mobs:
        count += 1

    if count < 6:
        m = Mob()
        all_sprites.add(m)
        mobs.add(m)
    screen.fill(BLACK)
    all_sprites.draw(screen)
    draw_text(screen, str(score), 50, WIDTH / 2, 10)
    draw_shield_bar(screen, 5, 5, player.shield)
    clock.tick(FPS)
    pygame.display.flip()


pygame.quit()
